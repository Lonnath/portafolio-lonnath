let toggler = document.getElementById('toggler');
let items_portafolio = document.getElementById('items-portafolio');
if(toggler.style.visibility === 'visible'){
    items_portafolio.style.display = 'block';
}else items_portafolio.style.display = '';